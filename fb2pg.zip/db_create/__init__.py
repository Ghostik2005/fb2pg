#init file

from .db_create import *

__version__ = "0.01"

